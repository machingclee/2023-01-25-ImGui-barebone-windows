class PReLU(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_251.PReLU,
    input: Tensor) -> Tensor:
    weight = self.weight
    return torch.prelu(input, weight)
