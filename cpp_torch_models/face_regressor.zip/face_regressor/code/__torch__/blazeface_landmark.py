class BlazeFaceLandmark(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  backbone1 : __torch__.torch.nn.modules.container.___torch_mangle_253.Sequential
  backbone2a : __torch__.torch.nn.modules.container.___torch_mangle_278.Sequential
  backbone2b : __torch__.torch.nn.modules.container.___torch_mangle_293.Sequential
  def forward(self: __torch__.blazeface_landmark.BlazeFaceLandmark,
    x: Tensor) -> Tuple[Tensor, Tensor]:
    backbone2b = self.backbone2b
    backbone2a = self.backbone2a
    backbone1 = self.backbone1
    input = torch.pad(x, [0, 1, 0, 1], "constant", 0.)
    _0 = (backbone1).forward(input, )
    _1 = torch.view((backbone2a).forward(_0, ), [-1, 468, 3])
    _2 = torch.div(_1, CONSTANTS.c0)
    _3 = torch.sigmoid((backbone2b).forward(_0, ))
    return (torch.view(_3, [-1]), _2)
