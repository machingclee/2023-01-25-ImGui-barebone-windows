class BlazeBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  max_pool : __torch__.torch.nn.modules.pooling.___torch_mangle_237.MaxPool2d
  convs : __torch__.torch.nn.modules.container.___torch_mangle_240.Sequential
  act : __torch__.torch.nn.modules.activation.___torch_mangle_241.PReLU
  def forward(self: __torch__.blazebase.___torch_mangle_242.BlazeBlock,
    argument_1: Tensor) -> Tensor:
    act = self.act
    convs = self.convs
    max_pool = self.max_pool
    input = torch.pad(argument_1, [0, 2, 0, 2], "constant", 0.)
    _0 = (max_pool).forward(argument_1, )
    input0 = torch.add((convs).forward(input, ), _0)
    return (act).forward(input0, )
