class BlazeBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convs : __torch__.torch.nn.modules.container.___torch_mangle_213.Sequential
  act : __torch__.torch.nn.modules.activation.___torch_mangle_214.PReLU
  def forward(self: __torch__.blazebase.___torch_mangle_215.BlazeBlock,
    argument_1: Tensor) -> Tensor:
    act = self.act
    convs = self.convs
    input = torch.add((convs).forward(argument_1, ), argument_1)
    return (act).forward(input, )
