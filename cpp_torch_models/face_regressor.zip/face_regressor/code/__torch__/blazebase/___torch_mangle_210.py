class BlazeBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  max_pool : __torch__.torch.nn.modules.pooling.___torch_mangle_205.MaxPool2d
  convs : __torch__.torch.nn.modules.container.___torch_mangle_208.Sequential
  act : __torch__.torch.nn.modules.activation.___torch_mangle_209.PReLU
  def forward(self: __torch__.blazebase.___torch_mangle_210.BlazeBlock,
    argument_1: Tensor) -> Tensor:
    act = self.act
    convs = self.convs
    max_pool = self.max_pool
    input = torch.pad(argument_1, [0, 2, 0, 2], "constant", 0.)
    x = torch.pad((max_pool).forward(argument_1, ), [0, 0, 0, 0, 0, 32], "constant", 0.)
    input0 = torch.add((convs).forward(input, ), x)
    return (act).forward(input0, )
