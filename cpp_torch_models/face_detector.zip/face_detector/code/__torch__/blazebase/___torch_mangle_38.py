class BlazeBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convs : __torch__.torch.nn.modules.container.___torch_mangle_36.Sequential
  act : __torch__.torch.nn.modules.activation.___torch_mangle_37.ReLU
  def forward(self: __torch__.blazebase.___torch_mangle_38.BlazeBlock,
    argument_1: Tensor) -> Tensor:
    act = self.act
    convs = self.convs
    x = torch.pad(argument_1, [0, 0, 0, 0, 0, 8], "constant", 0.)
    input = torch.add((convs).forward(argument_1, ), x)
    return (act).forward(input, )
