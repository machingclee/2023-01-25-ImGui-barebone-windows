class BlazeBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  convs : __torch__.torch.nn.modules.container.___torch_mangle_20.Sequential
  act : __torch__.torch.nn.modules.activation.___torch_mangle_21.ReLU
  def forward(self: __torch__.blazebase.___torch_mangle_22.BlazeBlock,
    argument_1: Tensor) -> Tensor:
    act = self.act
    convs = self.convs
    x = torch.pad(argument_1, [0, 0, 0, 0, 0, 6], "constant", 0.)
    input = torch.add((convs).forward(argument_1, ), x)
    return (act).forward(input, )
