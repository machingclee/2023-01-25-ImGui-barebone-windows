class BlazeFace(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  backbone1 : __torch__.torch.nn.modules.container.___torch_mangle_54.Sequential
  backbone2 : __torch__.torch.nn.modules.container.___torch_mangle_81.Sequential
  classifier_8 : __torch__.torch.nn.modules.conv.___torch_mangle_82.Conv2d
  classifier_16 : __torch__.torch.nn.modules.conv.___torch_mangle_83.Conv2d
  regressor_8 : __torch__.torch.nn.modules.conv.___torch_mangle_84.Conv2d
  regressor_16 : __torch__.torch.nn.modules.conv.___torch_mangle_85.Conv2d
  def forward(self: __torch__.blazeface.BlazeFace,
    x: Tensor) -> List[Tensor]:
    regressor_16 = self.regressor_16
    regressor_8 = self.regressor_8
    classifier_16 = self.classifier_16
    classifier_8 = self.classifier_8
    backbone2 = self.backbone2
    backbone1 = self.backbone1
    x0 = torch.pad(x, [1, 2, 1, 2], "constant", 0.)
    b = ops.prim.NumToTensor(torch.size(x0, 0))
    _0 = int(b)
    _1 = int(b)
    _2 = int(b)
    _3 = int(b)
    _4 = (backbone1).forward(x0, )
    _5 = (backbone2).forward(_4, )
    c1 = torch.permute((classifier_8).forward(_4, ), [0, 2, 3, 1])
    c10 = torch.reshape(c1, [_3, -1, 1])
    c2 = torch.permute((classifier_16).forward(_5, ), [0, 2, 3, 1])
    c20 = torch.reshape(c2, [_2, -1, 1])
    _6 = torch.cat([c10, c20], 1)
    r1 = torch.permute((regressor_8).forward(_4, ), [0, 2, 3, 1])
    r10 = torch.reshape(r1, [_1, -1, 16])
    r2 = torch.permute((regressor_16).forward(_5, ), [0, 2, 3, 1])
    r20 = torch.reshape(r2, [_0, -1, 16])
    return [torch.cat([r10, r20], 1), _6]
